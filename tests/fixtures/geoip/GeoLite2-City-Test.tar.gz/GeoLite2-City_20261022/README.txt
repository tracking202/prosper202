MaxMind test data (MaxMind-DB repository, MIT or Apache-2.0), packed as a GeoLite2 download is.
